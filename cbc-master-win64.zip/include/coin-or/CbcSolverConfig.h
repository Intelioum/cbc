/* src/config_cbcsolver.h.  Generated from config_cbcsolver.h.in by configure.  */
/* src/config_cbcsolver.h.in. */

#ifndef __CONFIG_CBCSOLVER_H__
#define __CONFIG_CBCSOLVER_H__

/* Library Visibility Attribute */
#define CBCSOLVERLIB_EXPORT __declspec(dllimport)

#endif
